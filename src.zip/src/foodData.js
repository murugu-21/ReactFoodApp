export default [
    {
        name: "Pongal",
        photoUrl: "https://cdn.shortpixel.ai/client/to_webp,q_glossy,ret_img,w_720/https://masalachilli.com/wp-content/uploads/2018/01/Ven-Pongal-Recipe-3.jpg",
        description: "Pongal with sambar and chutney",
        price: "Rs.45"
    },
    {
        name: "Idly",
        photoUrl: "https://www.sailusfood.com/wp-content/uploads/2015/02/idli-recipe.jpg",
        description: "set of 2 idlies with sambar and chutney",
        price: "Rs.30"
    },
    {
        name: "Dosa",
        photoUrl: "https://www.pbs.org/food/wp-content/blogs.dir/2/files/2013/08/nk-wgbh-masala-dosa640x360.jpg",
        description: "dosa with sambar and chutney",
        price: "Rs.50"
    },
    {
        name: "Fried Rice",
        photoUrl: "https://food.fnr.sndimg.com/content/dam/images/food/fullset/2013/9/12/0/FNK_Fried-Rice_s4x3.jpg.rend.hgtvcom.826.620.suffix/1594918949644.jpeg",
        description: "A bowl of fried rice with ketchup",
        price: "Rs.60"
    },
    {
        name: "Curd Rice",
        photoUrl: "https://www.cookwithmanali.com/wp-content/uploads/2015/01/Curd-Rice-South-Indian.jpg",
        description: "A bowl of curd rice with pickle",
        price: "Rs.30"
    },
];